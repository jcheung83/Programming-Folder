JS functionality:

Sign in/sign out button works
Click the thumbs up
Click edit profile
Adding or refusing connections